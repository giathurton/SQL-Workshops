USE sakila;

# Task 2

SELECT name AS 'Category Name', title AS 'Film Title', description AS 'Film Description', release_year AS 'Release Year' 
from category,film_category,film 
where category.category_id=film_category.category_id and film_category.film_id=film.film_id and name='Documentary' and description like '%Drama%';

#Task 3

Select title as 'Film title',first_name AS 'Actor first name', last_name AS 'Actor last name'
FROM film,actor
WHERE first_name= 'JULIA' AND last_name='MCQUEEN';

#Task 4

Select title as 'Film title',first_name AS 'Actor first name', last_name AS 'Actor last name'
FROM film,actor
WHERE title= 'AMADEUS HOLY';

#Task 5
SELECT * FROM customer INNER JOIN rental ON customer.customer_id = rental.customer_id
INNER JOIN inventory ON customer.store_id = inventory.store_id
INNER JOIN film ON inventory.film_id = film.film_id
WHERE CONCAT_WS( " ", customer.first_name, customer.last_name ) = "KATHLEEN ADAMS";

#Task 6
#Question 1 List all of the staff at a particular store
#Question 2 List when a particular customer joined
#Question 3 List all of the movies rented by a particular customer

